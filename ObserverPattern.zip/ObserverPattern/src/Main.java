import SubscribersObserver.Netflix;
import SubscribersObserver.Subscriber;
import SubscriptionPlanDecorator.*;
import SubscriptionPlanDecorator.Genres.AnyGenre;
import SubscriptionPlanDecorator.Genres.DisneyGenre;
import SubscriptionPlanDecorator.Genres.DreamWorksGenre;
import SubscriptionPlanDecorator.Genres.Genre;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //SubscribersObserver.Netflix application
        Netflix netflix = new Netflix();

        Subscription basic = new BasicSubscription();
        Subscription standard = new StandardSubscription(new BasicSubscription());
        Subscription premium = new PremiumSubscription(new StandardSubscription(new BasicSubscription()));

        Genre anyGenre = new AnyGenre();
        Genre disney = new DisneyGenre(new AnyGenre());
        Genre dreamWorks = new DreamWorksGenre(new AnyGenre());



        ask(basic, standard, premium, disney, dreamWorks);
    }

    public static void ask(Subscription basic, Subscription standard, Subscription premium, Genre disney, Genre dreamWorks) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Hello, what's your name?");
        String name = scanner.next();
        System.out.println("Would you like to watch netflix? ");
        System.out.println("Press 1 if yes, 0 if no");
        int answer = scanner.nextInt();
        if (answer == 1) {
            System.out.println("Great! What plan do you want? Press\n"
                    + "1 if basic\n" + "2 if standard\n" + "3 if premium");
            answer = scanner.nextInt();
            if (answer == 1) {
                Subscriber subscriber = new Subscriber(name, basic);
                System.out.println("Good, what you will get: ");
                System.out.println(subscriber.getSubscription().showQuality());
                System.out.print("Price: ");
                System.out.println(subscriber.getSubscription().totalPrice() + " $");

                System.out.println("Do you want some genres to add, but cost will increase?");
                System.out.println("Press 1 if yes, 0 if no");
                answer = scanner.nextInt();
                if (answer == 1) {
                    System.out.println("Alright! What genres do you want? Press\n"
                            + "1 if disney\n" + "2 if dreamworks");
                    answer = scanner.nextInt();
                    if (answer == 1) {
                        System.out.println("Good!");
                        subscriber.getSubscription().addGenre(disney);
                        System.out.println("Alright, your total price is: ");
                        System.out.println(subscriber.getSubscription().totalPrice());
                    } else if (answer == 2) {
                        System.out.println("Good!");
                        subscriber.getSubscription().addGenre(dreamWorks);
                        System.out.println("Alright, your total price is: ");
                        System.out.println(subscriber.getSubscription().totalPrice());
                    }
                } else if (answer == 0) {
                    System.out.println("OK");
                    System.out.println("Alright, your total price is: ");
                    System.out.println(subscriber.getSubscription().totalPrice());
                } else System.out.println("Please select one from the options");
            } else if (answer == 2) {
                Subscriber subscriber = new Subscriber(name, standard);
                System.out.println("Good, what you will get: ");
                System.out.println(subscriber.getSubscription().showQuality());
                System.out.print("Price: ");
                System.out.println(subscriber.getSubscription().totalPrice() + " $");

                System.out.println("Do you want some genres to add, but cost will increase?");
                System.out.println("Press 1 if yes, 0 if no");
                answer = scanner.nextInt();
                if (answer == 1) {
                    System.out.println("Alright! What genres do you want? Press\n"
                            + "1 if disney\n" + "2 if dreamworks");
                    answer = scanner.nextInt();
                    if (answer == 1) {
                        System.out.println("Good!");
                        subscriber.getSubscription().addGenre(disney);
                        System.out.println("Alright, your total price is: ");
                        System.out.println(subscriber.getSubscription().totalPrice());
                    } else if (answer == 2) {
                        System.out.println("Good!");
                        subscriber.getSubscription().addGenre(dreamWorks);
                        System.out.println("Alright, your total price is: ");
                        System.out.println(subscriber.getSubscription().totalPrice());
                    }
                } else if (answer == 0) {
                    System.out.println("OK");
                    System.out.println("Alright, your total price is: ");
                    System.out.println(subscriber.getSubscription().totalPrice());
                } else System.out.println("Please select one from the options");
            } else if (answer == 3){
                Subscriber subscriber = new Subscriber(name, premium);
                System.out.println("Good, what you will get: ");
                System.out.println(subscriber.getSubscription().showQuality());
                System.out.print("Price: ");
                System.out.println(subscriber.getSubscription().totalPrice() + " $");
            } else
                System.out.println("Please select one from the options");
        } else
            System.out.println("oh...ok");
    }
}
