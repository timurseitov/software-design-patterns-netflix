package SubscriptionPlanDecorator;

import SubscriptionPlanDecorator.Genres.Genre;

public interface Subscription {
    String showQuality();

    String getSubscriptionName();

    double price();

    double addGenre(Genre genre);

    double totalPrice();
}
