package SubscriptionPlanDecorator.Genres;

public interface Genre {
    double price();
}
