package SubscriptionPlanDecorator;

public class PremiumSubscription extends SubscriptionDecorator {

    private double sumCost = price();

    public PremiumSubscription(Subscription subscription) {
        super(subscription);
    }

    @Override
    public String showQuality() {
        return super.showQuality() + ", 4K Ultra HD";
    }

    @Override
    public double price() {
        sumCost = super.price() + 10;
        return sumCost;
    }

    public double totalPrice() {
        return sumCost;
    }

    public String getSubscriptionName() {
        return "premium";
    }
}
