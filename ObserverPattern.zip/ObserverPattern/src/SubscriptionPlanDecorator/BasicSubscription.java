package SubscriptionPlanDecorator;

import SubscriptionPlanDecorator.Genres.Genre;

public class BasicSubscription implements Subscription {

    private double sumCost = price();

    public BasicSubscription () {

    }

    public BasicSubscription (Genre genre) {
        addGenre(genre);
    }

    @Override
    public String showQuality() {
        return "Video quality can be: 480";
    }

    @Override
    public String getSubscriptionName() {
        return "basic";
    }

    @Override
    public double price() {
        return 10;
    }

    public double totalPrice() {
        return sumCost;
    }

    @Override
    public double addGenre(Genre genre) {
        sumCost = sumCost + genre.price();
        return sumCost;
    }


}
