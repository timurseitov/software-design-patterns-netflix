package SubscribersObserver;

public interface Subject {
    void addObserver(Subscriber observer);
    void removeObserver(Subscriber observer);
    void notifyAllObservers();
}
