package SubscribersObserver;

import SubscriptionPlanDecorator.Subscription;

import java.util.ArrayList;
import java.util.List;

public class Netflix implements Subject {

    public List<Subscriber> subscribers;
    private List<String> films;
    private String film;

    public Netflix() {
        subscribers = new ArrayList<>();
        films = new ArrayList<>();
    }

    public void addNewFilm(String filmName) {
        this.film = filmName;
        films.add(filmName);
        notifyAllObservers();
    }

    public void removeFilm(String filmName) {
        this.film = filmName;
        films.remove(filmName);
        notifyAllObservers();
    }

    @Override
    public void addObserver(Subscriber observer) {
        subscribers.add(observer);
    }

    @Override
    public void removeObserver(Subscriber observer) {
        subscribers.remove(observer);
    }

    @Override
    public void notifyAllObservers() {
        for (MyObserver subscriber : subscribers) {
            subscriber.update(film);
        }
    }

    public void showFilms() {
        System.out.println(films.toString());
    }

    public void showSubscribers() {
        for (int i = 0; i < subscribers.size(); i++) {
            System.out.print(subscribers.get(i).getName() + " ");
        }
    }

    public void showSubscriberWithPlan(Subscription subscription) {
        for (Subscriber subscriber : subscribers) {
            if (subscriber.getSubscription().equals(subscription)) {
                System.out.println(subscriber.getName());
            }
        }
    }
}
