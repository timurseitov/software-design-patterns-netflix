package SubscribersObserver;

import Media.Media;

import java.util.List;

public interface MyObserver {
    void update(Media media);

}
