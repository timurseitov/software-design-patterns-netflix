package Media;

public interface MediaFactory {
    Media createMedia();
}
