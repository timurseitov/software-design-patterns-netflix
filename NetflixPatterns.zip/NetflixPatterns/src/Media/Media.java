package Media;

public interface Media {


     String getName();

     void setName(String name);

     int getReleaseYear();

     void setReleaseYear(int releaseYear);


}
